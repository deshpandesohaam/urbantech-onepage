# UrbanTech Onepage (Full Version)
This folder contains the complete one-page responsive website.

## Deploy using GitHub Pages
1. Create a new GitHub repo: `urbantech-onepage`
2. Upload `index.html`
3. Go to **Settings → Pages**
4. Select **main branch** and **root folder**
5. Save → Your site goes live!
